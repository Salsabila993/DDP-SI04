import main 

print (" Perhitungan ")

#Menghitung Bangun Datar

main.l_persegi (10)

main.persegi_panjang (5, 5)

main.l_segitiga (3, 8)

main.l_lingkaran (6, 9)

main.l_jajargenjang (5, 8)

#Menghitung Bangun Ruang

main.l_kubus (6)

main.l_balok (9,6,4)

main.l_tabung (4,8)

main.l_kerucut (2,7)

main.l_bola (6)

