import math
#modul menghitung bangun datar
def l_persegi (sisi):
    luas = sisi * sisi
    kel = sisi * sisi * sisi * sisi
    print(f'Luas persegi {sisi} * {sisi} = {luas}')
    print(f'Keliling Persegi {kel}')
    
def persegi_panjang (panjang, lebar):
    luas = panjang * lebar
    print('Hasil luas persegi panjang dari', panjang, 'x', lebar, '=', luas)

def l_segitiga (alas, tinggi):
    luas = 1.2 * alas * tinggi 
    print(f'Luas segitiga {1/2} * {alas} * {tinggi} = {luas}')
    
def l_lingkaran (r1, r2):
    phi = 3.14
    luas = phi * r1 * r2
    print(f'luas lingkaran adalah phi * {r1} * {r2} = {luas}')
    
def l_jajargenjang (alas , tinggi):
    luas = alas * tinggi
    print(f'luas jajargenjang {alas} * {tinggi} = {luas}')
    
#Bangun Ruang

def l_kubus(sisi):
    luas = 6 * (sisi ** 2)
    print(f"Luas Kubus 6 x ({sisi} x {sisi}) = {luas}")

def l_balok(panjang, lebar, tinggi):
    luas = 2 * ((panjang * lebar) + (panjang * tinggi) + (lebar * tinggi))
    print(f"Luas Balok 2 x ({panjang} x {lebar} + {panjang} x {tinggi} + {lebar} x {tinggi}) = {luas}")

def l_tabung(jari, tinggi):
    luas = 2 * 3.14 * jari * (jari + tinggi)
    print(f"Luas Tabung 2 x phi x {jari} x ({jari} + {tinggi}) = {luas}")

def l_kerucut(jari, tinggi):
    luas = 3.14 * jari * (jari + math.sqrt((tinggi ** 2) + (jari ** 2)))
    print(f"Luas Kerucut phi x {jari} x ({jari} + √({tinggi}² + {jari}²)) = {luas}")

def l_bola(jari):
    luas = 4 * 3.14 * (jari ** 2)
    print(f"Luas Bola 4 x phi x ({jari} x {jari}) = {luas}")
